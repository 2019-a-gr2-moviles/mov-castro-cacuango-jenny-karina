package com.example.a02_android

class Persona(var nombre: String,
              var cedula: String
) {}